import fs from 'fs-extra';
import path from 'path';
import axios from 'axios';
import FormData from 'form-data';
import pkg from '@whiskeysockets/baileys';
const { downloadContentFromMessage, generateWAMessageFromContent, prepareWAMessageMedia } = pkg;

const DB_PATH = path.join(process.cwd(), 'src', 'upload_web.json');

const VERCEL_API = 'https://luffy-bot.nour-dev.xyz'; 
const CATBOX_USERHASH = '944145b0558412de8090cb6cb'; 

fs.ensureFileSync(DB_PATH);
if (fs.readFileSync(DB_PATH, 'utf-8').trim() === '') {
    fs.writeJsonSync(DB_PATH, { user_chats: {} });
}

async function syncToVercel(siteId, siteData) {
    try {
        await axios.post(`${VERCEL_API}/register-site`, {
            siteId: siteId,
            catboxUrl: siteData.catbox_url,
            status: siteData.status,
            password_protected: siteData.password_protected,
            password: siteData.password
        });
        return true;
    } catch (e) {
        console.error(`❌ خطأ أثناء مزامنة الموقع ${siteId} مع Vercel:`, e.message);
        return false;
    }
}

async function sendIAMessage(conn, jid, buttons, quoted, options = {}) {
    let media = null;
    if (options.media) {
        media = await prepareWAMessageMedia(
            { image: { url: options.media } },
            { upload: conn.waUploadToServer }
        );
    }

    let msg = generateWAMessageFromContent(jid, {
        viewOnceMessage: {
            message: {
                messageContextInfo: {
                    deviceListMetadata: {},
                    deviceListMetadataVersion: 2
                },
                interactiveMessage: {
                    header: {
                        title: options.header || "",
                        hasMediaAttachment: !!media,
                        ...media
                    },
                    body: { text: options.content || "" },
                    footer: { text: options.footer || "" },
                    nativeFlowMessage: { buttons: buttons },
                    contextInfo: {
                        mentionedJid: options.mentions || [],
                        isForwarded: false
                    }
                }
            }
        }
    }, { quoted });

    return await conn.relayMessage(jid, msg.message, {});
}

async function uploadToCatbox(fileBuffer, fileName) {
    const form = new FormData();
    form.append('reqtype', 'fileupload');
    form.append('userhash', CATBOX_USERHASH);
    form.append('fileToUpload', fileBuffer, { filename: fileName, contentType: 'text/html' });

    try {
        const response = await axios.post('https://catbox.moe/user/api.php', form, { 
            headers: {
                ...form.getHeaders(),
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
            } 
        });
        const resData = response.data.trim();
        if (response.status === 200 && resData.startsWith('http')) {
            return resData;
        }
        return null;
    } catch (e) {
        console.error('❌ خطأ أثناء الرفع إلى Catbox:', e.message);
        return null;
    }
}

let handler = async (m, { conn, sock, args, usedPrefix, command }) => {
    const conn = conn || sock; 
    const chat = m.chat || m.key.remoteJid;
    const sender = m.key.participant || m.key.remoteJid;
    
    const db = fs.readJsonSync(DB_PATH);
    if (!db.user_chats[sender]) db.user_chats[sender] = { sites: [] };

    const action = args[0]?.toLowerCase();

    if (!action) {
        await conn.sendMessage(chat, { react: { text: '🌐', key: m.key } });

        let helpText = `⚡ *سيستم الاستضافة الفورية العبقري (Luffy Cloud)*\n`;
        helpText += `— — — — — — — — — — — — — —\n`;
        helpText += `🔹 \`${usedPrefix}${command} رفع\` 👈🏻 (دير ريبلاي لملف الـ HTML)\n`;
        helpText += `🔹 \`${usedPrefix}${command} قائمة\` 👈🏻 لعرض كل مواقعك المرفوعة\n`;
        helpText += `🔹 \`${usedPrefix}${command} تحكم [ID]\` 👈🏻 لفتح لوحة تحكم موقعك\n`;
        helpText += `🔹 \`${usedPrefix}${command} صيانة [ID]\` 👈🏻 لتشغيل/إيقاف وضع الصيانة\n`;
        helpText += `🔹 \`${usedPrefix}${command} قفل [ID] [الباسورد]\` 👈🏻 لحماية الموقع برمز\n`;
        helpText += `🔹 \`${usedPrefix}${command} سورس [ID]\` 👈🏻 لتحميل كود الـ HTML الأصلي\n`;
        helpText += `🔹 \`${usedPrefix}${command} حذف [ID]\` 👈🏻 لحذف الموقع من البوت\n`;
        helpText += `— — — — — — — — — — — — — —\n🏴‍☠️ *الـدومـيـن:* luffy-bot.nour-dev.xyz`;

        const buttons = [
            {
                name: "quick_reply",
                buttonParamsJson: JSON.stringify({ display_text: "📂 عرض قائمة مواقعي", id: `${usedPrefix}${command} قائمة` })
            }
        ];

        return await sendIAMessage(conn, chat, buttons, m, {
            header: "𝐿𝑈𝐹𝐹𝑌 𝐵𝛩𝑇⚡⃝⃕𝆺𝅥𝆹𝅥",
            content: helpText,
            footer: "◁ تـطـويـر وإدارة : 𝑁𝑜𝑢𝑟 𝑑𝑒𝑣 🕷️",
            media: "https://files.catbox.moe/39im83.jpg",
            mentions: [sender]
        });
    }

    if (action === 'رفع' || action === 'صنع') {
        const quoted = m.message?.extendedTextMessage?.contextInfo?.quotedMessage;
        const documentMessage = quoted?.documentMessage;

        if (!documentMessage || !documentMessage.fileName.endsWith('.html')) {
            return conn.sendMessage(chat, { text: '⚠️ *عذراً! يجب عليك الرد (Reply) على ملف بصيغة HTML فقط!*' }, { quoted: m });
        }

        await conn.sendMessage(chat, { text: '🔍 *جاري معالجة الملف ورفعه على السيرفر السحابي...*' }, { quoted: m });

        const stream = await downloadContentFromMessage(documentMessage, 'document');
        let buffer = Buffer.from([]);
        for await (const chunk of stream) { buffer = Buffer.concat([buffer, chunk]); }

        const siteId = 'site_' + Math.floor(1000 + Math.random() * 9000);
        const fileName = documentMessage.fileName;

        const rawCatboxUrl = await uploadToCatbox(buffer, fileName);
        if (!rawCatboxUrl) return conn.sendMessage(chat, { text: '❌ *حدث خطأ أثناء الرفع إلى المستودع المركزي!*' }, { quoted: m });

        const webViewUrl = `${VERCEL_API}/${siteId}`;

        const newSite = {
            site_id: siteId, file_name: fileName, raw_source: buffer.toString('base64'), catbox_url: rawCatboxUrl,
            url: webViewUrl, created_at: new Date().toISOString().split('T')[0], status: 'active', password_protected: false, password: ''
        };

        const synced = await syncToVercel(siteId, newSite);
        if (!synced) return conn.sendMessage(chat, { text: '❌ *فشل الاتصال بـ Vercel API، تأكد من الـ سكريبت!*' }, { quoted: m });

        db.user_chats[sender].sites.push(newSite);
        fs.writeJsonSync(DB_PATH, db);

        let resText = `✨ *تم إنشاء موقعك بنجاح على سيرفرك الخاص!*\n\n`;
        resText += `🆔 *المعرف:* \`${siteId}\`\n🌐 *الرابط:* ${webViewUrl}\n\n`;
        resText += `👇🏻 استخدم الأزرار لفتح الموقع أو إدارته:`;

        const successButtons = [
            {
                name: "cta_url",
                buttonParamsJson: JSON.stringify({ display_text: "🌐 فتح الموقع المرفوع", url: webViewUrl })
            },
            {
                name: "quick_reply",
                buttonParamsJson: JSON.stringify({ display_text: "⚙️ فتح لوحة التحكم", id: `${usedPrefix}${command} تحكم ${siteId}` })
            }
        ];

        return await sendIAMessage(conn, chat, successButtons, m, {
            header: "        𝐿𝑈𝐹𝐹𝑌 𝐵𝛩𝑇⚡⃝⃕𝆺𝅥𝆹𝅥",
            content: resText,
            footer: "◁ تـطـويـر : 𝑁𝑜𝑢𝑟 𝑑𝑒𝑣 🕷️",
            media: "https://files.catbox.moe/39im83.jpg",
            mentions: [sender]
        });
    }

    if (action === 'قائمة' || action === 'مواكعي') {
        const userSites = db.user_chats[sender].sites;
        if (userSites.length === 0) return conn.sendMessage(chat, { text: '📂 *ليس لديك أي مواقع مرفوعة حالياً.*' }, { quoted: m });

        let listText = `📂 *مواقعك الحالية المرفوعة (${userSites.length}):*\n\n`;
        listText += `اختر الموقع لي بغيتي تعدلو من القائمة التحت:`;

        const rows = userSites.map((site, index) => ({
            header: `🌐 موقع رقم ${index + 1}`,
            title: site.file_name,
            description: `🆔: ${site.site_id} | ${site.status === 'active' ? '🟢 شغال' : '🛠️ صيانة'}`,
            id: `${usedPrefix}${command} تحكم ${site.site_id}`
        }));

        const listButtons = [
            {
                name: 'single_select',
                buttonParamsJson: JSON.stringify({
                    title: '📂 قائمة مواقعك الإلكترونية',
                    sections: [{ title: '✨ اختر موقعاً لإدارته', rows: rows }]
                })
            }
        ];

        return await sendIAMessage(conn, chat, listButtons, m, {
            header: "       𝐿𝑈𝐹𝐹𝑌 𝐵𝛩𝑇⚡⃝⃕𝆺𝅥𝆹𝅥",
            content: listText,
            footer: "◁ تـطـويـر : 𝑁𝑜𝑢𝑟 𝑑𝑒𝑣 🕷️",
            media: "https://files.catbox.moe/39im83.jpg",
            mentions: [sender]
        });
    }

    // --- 3️⃣ لوحة التحكم السريعة بالأزرار ---
    if (action === 'تحكم') {
        const targetId = args[1];
        const site = db.user_chats[sender].sites.find(s => s.site_id === targetId);
        if (!site) return conn.sendMessage(chat, { text: '❌ *الموقع غير موجود أو لا تملكه!*' }, { quoted: m });

        let panel = `🛠️ *لوحة تحكم الموقع: ${site.file_name}*\n\n`;
        panel += `🚦 *الحالة الحالية:* \`${site.status === 'active' ? '🟢 شغال علناً' : '🛠️ تحت الصيانة'}\`\n`;
        panel += `🔒 *الحماية:* \`${site.password_protected ? '🔒 مقفل بـ (' + site.password + ')' : '🔓 مفتوح للكل'}\`\n`;
        panel += `🔗 *الرابط:* ${site.url}\n\n`;
        panel += `👇🏻 *اضغط على الأزرار السريعة للتحكم الفوري:*`;

        const controlButtons = [
            {
                name: "quick_reply",
                buttonParamsJson: JSON.stringify({ display_text: "🚦 تشغيل/إيقاف الصيانة", id: `${usedPrefix}${command} صيانة ${targetId}` })
            },
            {
                name: "quick_reply",
                buttonParamsJson: JSON.stringify({ display_text: "📥 تحميل ملف السورس", id: `${usedPrefix}${command} سورس ${targetId}` })
            },
            {
                name: "quick_reply",
                buttonParamsJson: JSON.stringify({ display_text: "🗑️ حذف الموقع نهائياً", id: `${usedPrefix}${command} حذف ${targetId}` })
            }
        ];

        return await sendIAMessage(conn, chat, controlButtons, m, {
            header: `⚙️ 𝒞𝒪𝒩𝒯𝒩𝒪ℒ 𝒫𝒜𝒩ℰ𝄗: ${targetId}`,
            content: panel,
            footer: "◁ تـطـويـر : 𝑁𝑜𝑢𝑟 𝑑𝑒𝑣 🕷️",
            media: "https://files.catbox.moe/39im83.jpg",
            mentions: [sender]
        });
    }

    if (action === 'صيانة') {
        const targetId = args[1];
        const siteIndex = db.user_chats[sender].sites.findIndex(s => s.site_id === targetId);
        if (siteIndex === -1) return conn.sendMessage(chat, { text: '❌ المعرف غير صحيح.' }, { quoted: m });

        let site = db.user_chats[sender].sites[siteIndex];
        site.status = site.status === 'active' ? 'maintenance' : 'active';

        await syncToVercel(targetId, site);
        fs.writeJsonSync(DB_PATH, db);
        
        return conn.sendMessage(chat, { text: `🚦 تم تحويل حالة الموقع إلى \`${site.status === 'active' ? '🟢 شغال علناً' : '🛠️ صيانة'}\` بنجاح!` }, { quoted: m })
            .then(() => handler(m, { conn, sock, args: ['تحكم', targetId], usedPrefix, command }));
    }

    if (action === 'قفل') {
        const targetId = args[1];
        const pass = args[2];
        const siteIndex = db.user_chats[sender].sites.findIndex(s => s.site_id === targetId);
        if (siteIndex === -1) return;

        let site = db.user_chats[sender].sites[siteIndex];
        if (!pass || pass === 'معطلة') {
            site.password_protected = false; site.password = '';
        } else {
            site.password_protected = true; site.password = pass;
        }

        await syncToVercel(targetId, site);
        fs.writeJsonSync(DB_PATH, db);

        return conn.sendMessage(chat, { text: `🔒 تم تحديث نظام حماية الموقع بنجاح!` }, { quoted: m })
            .then(() => handler(m, { conn, sock, args: ['تحكم', targetId], usedPrefix, command }));
    }

    if (action === 'سورس') {
        const targetId = args[1];
        const site = db.user_chats[sender].sites.find(s => s.site_id === targetId);
        if (!site) return;

        return conn.sendMessage(chat, { document: Buffer.from(site.raw_source, 'base64'), mimetype: 'text/html', fileName: site.file_name }, { quoted: m });
    }

    if (action === 'حذف') {
        const targetId = args[1];
        const siteIndex = db.user_chats[sender].sites.findIndex(s => s.site_id === targetId);
        if (siteIndex === -1) return;

        db.user_chats[sender].sites.splice(siteIndex, 1);
        fs.writeJsonSync(DB_PATH, db);
        return conn.sendMessage(chat, { text: `🗑️ تم حذف الموقع من سجلات البوت بنجاح.` }, { quoted: m });
    }
};

handler.command = ['ويب', 'web', 'استضافة'];
handler.tags = ['tools'];

export default handler;